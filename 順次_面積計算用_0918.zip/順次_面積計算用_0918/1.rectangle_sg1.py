import PySimpleGUI as sg            #PySimpleGUIライブラリをインポート　sg という略号を使ってコードを記述する。

layout = [[sg.Text('縦の長さ:'), sg.InputText(key = '-TATE-')],    #　縦の長さを入力するためのテキストボックス　key = '-TATE-'は、11行目で変数valuesに代入される辞書から、縦の長さを取り出すためのキーとして働く
          [sg.Text('横の長さ:'), sg.InputText(key = '-YOKO-')],    #　横の長さを入力するためのテキストボックス　key = '-YOKO-'は、11行目で変数valuesに代入される辞書から、横の長さを取り出すためのキーとして働く
          [sg.Button('計算', size = (10,3), pad = ((300,0),(10,10)))],   #　面積計算実行ボタン  size=(横,縦)はボタンそのもののサイズ　　pad=((左,右),(上,下))はButtonのパディング （内側余白）                            
          [sg.Text(key = '-OUTPUT-')]                              # 計算結果表示領域　key = '-OUTPUT-'は、21行目で、計算結果を表示するために使われる。（この場合は、辞書のキーではない。）
         ]
window = sg.Window('四角形の面積',layout)                           # GUIウィンドウを表示  (windowの横幅が狭すぎて、マウスのドラッグ操作で移動できない場合：layout, grab_anywhere=Trueを追記)

while True:                                                         # 無限ループを発生させ、
    event,values = window.read()                                    # ユーザ操作によって発生したイベントや、その結果生成される値が届くのを待ち受ける。届いたら、変数event、valuesに代入する。因みにvaluesはvalues = {'-TATE-': '100', '-YOKO-': '50'}　辞書型

    if event == sg.WIN_CLOSED:                                      #　ユーザが終了操作をしたら画面終了
        break

    if event == '計算':                                              #  ボタンクリックで計算イベントが発生したら
        縦 = float(values['-TATE-'])                                 #  変数「縦」に縦の長さを代入し ・・・　key -TATE-が活躍
        横 = float(values['-YOKO-'])                                 #  変数「横」に縦の長さを代入し ・・・  key -YOKO-が活躍
        面積 = 縦 * 横                                                #  関数を使って面積計算を実行

        window['-OUTPUT-'].update(f'四角形の面積:{面積}平方単位です。') # 計算結果を表示 ・・・  key -OUTPUT-が活躍

window.close()                                                       # ウィンドウを消去してすべて終了。