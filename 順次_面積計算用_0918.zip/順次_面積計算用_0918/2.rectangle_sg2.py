import PySimpleGUI as sg

layout = [[sg.Text('縦の長さ'),sg.InputText(key = '-TATE-')],
          [sg.Text('横の長さ'),sg.InputText(key = '-YOKO-')],
          [sg.Push(), sg.Button('計算', size=(10, 3)), sg.Button('Quit', size=(10, 3))],#前のコードと違うのは、「計算用ボタン」と「終了用ボタン」がウィンドウ内に置かれているところ。
          [sg.Text(key = '-OUTPUT-')]
]
window = sg.Window('四角形の面積',layout)

while True:
    event,values = window.read()

    # if event == sg.WIN_CLOSED:
    if event in(None,'Quit'):
        break
    if event == '計算':
        縦 = float(values['-TATE-'])
        横 = float(values['-YOKO-'])
        面積 = 縦 * 横

        window['-OUTPUT-'].update(f'四角形の面積:{面積}平方単位です。') 
        
window.close()